package com.dicoding.fruits.fruits

data class Fruits (
    var name: String = "",
    var image: Int = 0,
    var species: String = "",
    var detail: String = "",
    var overview: String = ""

)